nuke.load('ch_menu.py')

