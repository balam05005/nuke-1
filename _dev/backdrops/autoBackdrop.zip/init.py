nuke.pluginAddPath('./python')
nuke.pluginAddPath('./python/toolsTK')

import toolsTK.common as tk